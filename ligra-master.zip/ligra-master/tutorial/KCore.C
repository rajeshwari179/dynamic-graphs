#include "ligra.h"


//get vertices with degree less than k
//set their core number to k-1
//set their induced degree as 0
template<class vertex>
struct Deg_LessThan_K {
  vertex* V;
  long* coreNumbers;
  long* Degrees;
  long k;
  Deg_LessThan_K(vertex* _V, long* _Degrees, long* _coreNumbers, long _k) : 
    V(_V), k(_k), Degrees(_Degrees), coreNumbers(_coreNumbers) {}
  inline bool operator () (long i) {
    if (Degrees[i] < k) {
      coreNumbers[i] = k-1;
      Degrees[i] = 0;
      return true;
    }
    return false;
  }
};

//get vertices with degree at least k
template<class vertex>
struct Deg_AtLeast_K {
  vertex* V;
  long *Degrees;
  long k;
  Deg_AtLeast_K(vertex* _V, long* _Degrees, long _k) : 
    V(_V), k(_k), Degrees(_Degrees) {}
  inline bool operator () (long i) {
    //allow vertices whose degree is >=k
    return Degrees[i] >= k;
  }
};

//once the vertices with degree < k are removed, the degree of their neighbours should be updated
struct Update_Deg {
  long* Degrees;
  Update_Deg(long* _Degrees) : Degrees(_Degrees) {}
  inline bool updateAtomic (long s, long d){  //atomic update
    writeAdd(&Degrees[d],(long)-1);
    return 1;
    //return (fetchAndAdd(&Degrees[d],-1) == 1);

  }
  inline bool update (long s, long d) { 
    return updateAtomic(s,d);
  }
  inline bool cond (long d) { 
    return Degrees[d] > 0;
  }
};

//assumes symmetric graph
// 1) iterate over all remaining active vertices
// 2) for each active vertex, remove if induced degree < k. Any vertex removed has
//    core-number (k-1) (part of (k-1)-core, but not k-core)
// 3) stop once no vertices are removed. Vertices remaining are in the k-core.
template <class vertex>
void Compute(graph<vertex>& GA, commandLine P) {
  const long n = GA.n;
  //active vertex = degree k or more
  bool* active = newA(bool,n);
  {parallel_for(long i=0;i<n;i++) active[i] = 1;}
  //array of n bits which decides subset membership in O(1)
  vertexSubset Frontier(n, n, active);
  long* coreNumbers = new long[n];
  long* Degrees = new long[n];
  {parallel_for(long i=0;i<n;i++) {
      coreNumbers[i] = 0;
      Degrees[i] = GA.V[i].getOutDegree();
    }}

  //track largest core
  long largestCore = -1;

  for (long k = 1; k <= n; k++) {
    while (true) {
      //filter which removes vertices with degree less than k from the subset
      vertexSubset toRemove 
	= vertexFilter(Frontier,Deg_LessThan_K<vertex>(GA.V,Degrees,coreNumbers,k));
  //get vertices with degree >=k
      vertexSubset remaining = vertexFilter(Frontier,Deg_AtLeast_K<vertex>(GA.V,Degrees,k));
     //clear frontier and keep only the vertices with degree >=k 
      Frontier.del();
      Frontier = remaining;
      //if there are no more vertices with degree < k to be removed, the k-core has been found
      if (0 == toRemove.numNonzeros()) {
	toRemove.del();
        break;
      }
      //vertices are removed, so update their neighbours and continue
      else {
  //update the degree of the neighbours of the vertices removed
	vertexSubset output = edgeMap(GA,toRemove,Update_Deg(Degrees));
	toRemove.del(); output.del();
      }
    }
    //if subset is empty, then the largest core found was k-1 (no vertex has core number k)
    if(Frontier.numNonzeros() == 0) { largestCore = k-1; break; }
  }
  cout << "largestCore was " << largestCore << endl;
  //print core numbers of all vertices
  /*for (long i = 0; i < n; i++) {
    cout << "coreNumbers[" << i << "] = " << coreNumbers[i] << endl;
  }*/

  //get input filename
  // Get input filename from command line
   std::string inputFilename = P.getOptionValue("-i", "");
   //std::string inputFilename = "graph_shuffled_adj.txt";

    // Extract base filename (without extension)
    std::string baseFilename = inputFilename.substr(0, inputFilename.find_last_of("."));

    // Construct output filename
    std::string outputFilename = baseFilename + "_corenums.txt";

    // Write core numbers to file
    std::ofstream outFile(outputFilename);
    if (outFile.is_open()) {
        for (long i = 0; i < n; i++) {
             outFile << i << "," << coreNumbers[i] << "\n";
        }
        outFile.close();
        cout << "Core numbers have been written to 'corenums.txt'." << endl;
    } else {
        cout << "Error: Unable to open file 'corenums.txt' for writing." << endl;
    }




  Frontier.del(); free(coreNumbers); free(Degrees);
}
